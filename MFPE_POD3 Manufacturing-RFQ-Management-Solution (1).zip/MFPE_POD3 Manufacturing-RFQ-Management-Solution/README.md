---JAVA FSE---
---CDE21IJ028---

MFPE POD3
# Manufacturing-RFQ-Management

total Five microservices are Created
-Authentication
-Fabricate App
-Supplier Module
-Plant Module
-RFQ

three Zip Code are uploaded
-Main Code
-AWS Deployment Code
-AWS Deployment Screenshots

PPT link for reference:

https://docs.google.com/presentation/d/16UN0s01WIX4s7up9C9Mw6Ioslh2NFoQqZQG4DASwPfA/edit?usp=sharing